// Huda Mukhtar, Student ID: HMUKHTA
#include <stdio.h>
#include <stdlib.h>
#include "memory.h"

static unsigned char *memory;
static BStree bst;

// Input: ’size’: the number of elements of the memory block
// Effect: Initialize an unsigned char array of 
//         size elements and initialize a binary search tree.
void mem_ini(unsigned int size) {
	memory = (unsigned char *) malloc(size);
	bst = bstree_ini(size/5); // size/5 is large enough
	bstree_insert(bst, 0, size);
}

// Input: ’size’: the number of elements of the memory block
// Effect: Allocate size bytes and return a pointer to the first 
//         byte allocated.
void *simu_malloc(unsigned int size) {
	if (bstree_data_search(bst, size + 4) == NULL)
		return NULL;
	else {
		Key *space = bstree_data_search(bst, size + 4);
		Key key = *space;
		Data *dSize = bstree_search(bst, *space); 
		bstree_delete(bst, key);
		memory[*space] = size;
		if (0 < *dSize - 4 - size)
			bstree_insert(bst, 4 + size + *space, *dSize - size - 4);
		return &memory[4 + key];
	}
}

// Input: 'ptr': pointer
// Effect: Put the allocated memory pointed by ptr back to be free memory.
void simu_free(void *ptr) {
	Key *k = (Key*) ((unsigned char*)ptr - 4);
	bstree_insert(bst, (*bstree_data_search(bst,*k) - (4 + *k)), (4 + *k));
}

// Effect: Print all the free memory blocks.
void mem_print(void) {
	bstree_traversal(bst);
}

// Effect: Free memory used for the array and the binary search tree.
void mem_free(void) {
	bstree_free(bst);
}

