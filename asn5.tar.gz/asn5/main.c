// Huda Mukhtar, Student ID: HMUKHTA
#include <stdio.h>
#include "bst.h"
#include <string.h>
#include <stdlib.h>
#include "list.h"
#include "memory.h"

int main() {
    // initialize and request the size of the memory
    int size;
    scanf("%d", &size);
    mem_ini(size);
    // initialize the list 
    List list = list_ini();
    // initialize input of the numbers and their occurences
    int input;
    // create a loop to request the keys and the data
    while(scanf("%d", &input) != EOF){
        if (list_search(list, input) != NULL){
            int *occurences;
            occurences = list_search(list, input);
            *occurences = *occurences + 1;
        }
        else
            list_add(list, input, 1);
    }
    // print the keys and their data
    printf("In this case, the key is the integer and the data is the number of occurences\n");
    list_print(list);
    // free the list and the memory
    list_free(list);
    mem_free();

}
