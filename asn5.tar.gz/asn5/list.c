// Huda Mukhtar, Student ID: HMUKHTA
#include <stdio.h>
#include <stdlib.h>
#include "list.h"
#include "memory.h"

// Effect: Return a pointer to a dynamically allocated and initialized List
//         named head
List list_ini(void) {
	List_node *head = (List_node *) simu_malloc( sizeof(List_node) ); 
	head->next = NULL;
	return head;
}

// Input: 'list': the list with the keys and data
// Effect: return the data of the corresponding key if it is found, null otherwise
Data *list_search(List list, Key key) {
	List current = list->next;
	while(current != NULL) {
		if (key_comp(current->key, key) == 0)
			return &(current->data);
        current = current->next;
	}
	return NULL;
}

// Input: 'list': the list with the keys and data
//		  'key': the key to be deleted from the list
//        'data': the data to be added to the list
// Effect: 
void list_add(List list, Key key, Data data) {
	if (list_search(list, key) != NULL){
		return;
    }
    // Create a pointer to where the head points to
    List_node *HEAD = list->next;
	List_node *new_node = (List_node *) simu_malloc(sizeof(List_node) );
	new_node->data = data;
	new_node->key = key;
	new_node->next = HEAD;
	list->next = new_node;
}

// Input: 'list': the list with the keys and data
//		  'key': the key to be deleted from the list
// Effect: Delete the node in list with its key equals 
//         to key. If no such node in list, do nothing.
void list_delete(List list, Key key) {
	if (list_search(list, key) == NULL)
		return;
     // Set a current node for reference
     List curr = list->next;
     // CASE 1: If the node is at the beginning of the list
     if (key_comp(curr->key, key) == 0) {
         list->next = curr->next;
         // free the node
         simu_free(curr);
     }
    else {
        // set the previous node for reference
        List prev = list->next;
        // set the current node for reference
        curr = curr->next;
        // iterate through the entire list
        while (curr != NULL) {
            // check to see if the current node stores the key needed to be deleted
            // CASE 2: If the node is in the middle of the list
            if (key_comp(curr->key, key) == 0) {
                prev->next = curr->next;
                simu_free(curr);
            }
            prev = curr;
            curr = curr->next;
        }
        // CASE 3: When the node is at the end of the list
        if (key_comp(prev->key, key) == 0) {
                prev->next = NULL;
                simu_free(prev);
            }
    }

}

// Input: 'list': the list with the keys and data
// Effect: Linearly traversal the list and print each node’s key and data.
void list_print(List list) {
	List curr = list->next;
	while (curr != NULL){
	 	printf("Key: %d, Data: %d\n", curr->key, curr->data);
	 	curr = curr->next;
	 }
}

// Input: 'list': the list with the keys and data
// Effect: Free all the dynamically allocated memory of list.
void list_free(List list) {
	List curr = list->next;
	while(curr != NULL){
		simu_free(curr);
		curr = curr->next;
	}
}
